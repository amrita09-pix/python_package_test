def series(n):
    k=0
    for i in range(1,n+1):
        k=k+i
    return k

def factorial(n):
    k=1
    for i in range(1,n+1):
        k=k*i
    return k
