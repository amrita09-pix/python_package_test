# Temp Converter

A simple Python library to calculate basic series and factorial of a given number 
 Eg - n = 5
 series (5) = 5+4+3+2+1
 factorial (5) = 5*4*3*2*1

## Installation

```bash
pip install converter